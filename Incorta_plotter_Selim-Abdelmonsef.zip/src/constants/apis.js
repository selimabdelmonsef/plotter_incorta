export const api = {
    dimensionsMesaures_api: 'https://plotter-task.herokuapp.com/columns',
    postPlotterData_api: 'https://plotter-task.herokuapp.com/data'
}